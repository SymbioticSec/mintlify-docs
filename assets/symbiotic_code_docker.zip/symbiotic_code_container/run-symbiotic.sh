#!/usr/bin/env bash
# -------------------------------------------------------------------------
# run-symbiotic.sh
#
#  • Build the Docker image (symbiotic-node) if it does not already exist.
#  • Launch an interactive Node.js container with the Symbiotic CLI installed.
#  
#  • Any remaining arguments are forwarded to `docker run` (e.g. volume mounts).
#
#  
#      ./run-symbiotic.sh -- -v "$(pwd)":/work -w /work        # mount cwd
#      ./run-symbiotic.sh -- -c "symbiotic status"            # run one‑off cmd
#
#  The script is self‑contained – you can copy it anywhere, ensure it is
#  executable (`chmod +x run-symbiotic.sh`) and run it.
# -------------------------------------------------------------------------

set -euo pipefail

# -------------------------------------------------------------------------
# 1️⃣ Helper: build the image if it is missing (or if you ask to force‑rebuild)
# -------------------------------------------------------------------------
IMAGE_NAME="symbiotic-node"
DOCKERFILE_PATH="${BASH_SOURCE[0]%/*}/Dockerfile"   # same dir as this script

build_image() {
    echo "🔨 Building Docker image '${IMAGE_NAME}' from ${DOCKERFILE_PATH} ..."
    docker build --platform=linux/amd64 -t "${IMAGE_NAME}" -f "${DOCKERFILE_PATH}" .
    echo "✅ Image '${IMAGE_NAME}' ready."
}

# If the image is not present locally, build it
if ! docker image inspect "${IMAGE_NAME}" > /dev/null 2>&1; then
    build_image
fi

# -------------------------------------------------------------------------
# 2️⃣ Optional: force a rebuild (useful during development)
# -------------------------------------------------------------------------
if [[ "${1:-}" == "--rebuild" ]]; then
    shift
    build_image
fi


# -------------------------------------------------------------------------
# 4️⃣ Compose the `docker run` options
# -------------------------------------------------------------------------
DOCKER_OPTS=(
    --platform=linux/amd64
    --rm
    -it
    -w /home/node
)

# -------------------------------------------------
# If you like to mount the current directory by default,
# uncomment the two lines below.  (You can also pass -v … manually.)
# -------------------------------------------------
# DOCKER_OPTS+=(-v "$(pwd)":/home/node/work)
# DOCKER_OPTS+=(-w /home/node/work)

# Append any extra arguments supplied by the caller (e.g. -v, -e, --network)
DOCKER_OPTS+=("$@")

# -------------------------------------------------------------------------
# 5️⃣ Run the container
# -------------------------------------------------------------------------
echo "🚀 Launching container from image '${IMAGE_NAME}' ..."
docker run "${DOCKER_OPTS[@]}" "${IMAGE_NAME}"
